## A simple editor with auto-complete
### versions:
****
* alpha_2022.3.20:Main part is finished.